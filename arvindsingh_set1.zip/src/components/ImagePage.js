import React from 'react'

function ImagePage() {
  return (
    <div>
        <img src='https://strapi-catalog.s3.ap-south-1.amazonaws.com/Website_Banner_04_3ace99cd08.webp' alt='' style={{width:'100%',height:'90vh'}} />
    </div>
  )
}

export default ImagePage